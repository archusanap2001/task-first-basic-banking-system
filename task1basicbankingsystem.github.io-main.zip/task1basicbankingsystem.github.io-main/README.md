# BasicBankingSystem
***I have created the Basic Banking System as an intern for the Sparks Foundation.***
#GRIPFEB22

Intern @ Spark Foundation

Task 1: Basic Banking System

The Basic Banking System website function is to transfer money from one account to another account.

**FrontEnd: HTML, CSS, JS ***
***Backend: PHP***
***Database: MySQL***
      
